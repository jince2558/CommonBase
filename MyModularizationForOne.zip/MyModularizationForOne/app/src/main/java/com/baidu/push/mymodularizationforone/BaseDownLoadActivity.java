package com.baidu.push.mymodularizationforone;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;

import com.baidu.push.downloadactivity.DownLoadActivity;

public abstract class BaseDownLoadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResId());
        initView(addView());

    }
    public void initView(FrameLayout frameLayout) {
        View inflateView = LayoutInflater.from(BaseDownLoadActivity.this).inflate(com.baidu.push.downloadactivity.R.layout.activity_down_load, frameLayout, false);
    }

    /**
     * 获取布局
     * @return
     */
    protected abstract int getLayoutResId();

    protected abstract FrameLayout addView();

}
