package com.baidu.push.mymodularizationforone;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 初步搭建一个组件化的框架结构测试自己的需求
 * 第三方SDK版本控制
 */
public class MainActivity extends AppCompatActivity {


    @BindView(R.id.addlayout)
    FrameLayout addlayout;
    @BindView(R.id.main_hello)
    TextView mainHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initView();
    }

    private void initView() {
        mainHello.setText("你好");
    }
}
