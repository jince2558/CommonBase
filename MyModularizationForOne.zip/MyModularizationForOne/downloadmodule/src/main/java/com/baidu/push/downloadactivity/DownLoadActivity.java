package com.baidu.push.downloadactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

public abstract class DownLoadActivity extends AppCompatActivity {

    private TextView mTestView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResId());
//        initView(addView());

    }

//    public void initView(FrameLayout frameLayout) {
//        View inflateView = LayoutInflater.from(DownLoadActivity.this).inflate(R.layout.activity_down_load, frameLayout, false);
//    }


    /**
     * 获取布局
     * @return
     */
    protected abstract int getLayoutResId();

    protected abstract FrameLayout addView();

}
